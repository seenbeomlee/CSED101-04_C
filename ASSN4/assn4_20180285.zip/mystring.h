#ifndef MYSTRING_H
#define MYSTRING_H

int mystrlen(char *str);
char *mystrcpy(char *toStr, char *fromStr);
char *mystrcat(char *str1, char *str2);
char *mystrchr(char *str, char c);

#endif
